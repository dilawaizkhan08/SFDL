from setuptools import setup, find_packages

with open("requirements.txt") as f:
	install_requires = f.read().strip().split("\n")

# get version from __version__ variable in sfdl/__init__.py
from sfdl import __version__ as version

setup(
	name="sfdl",
	version=version,
	description="DNA based app",
	author="xyz",
	author_email="xyz",
	packages=find_packages(),
	zip_safe=False,
	include_package_data=True,
	install_requires=install_requires
)
